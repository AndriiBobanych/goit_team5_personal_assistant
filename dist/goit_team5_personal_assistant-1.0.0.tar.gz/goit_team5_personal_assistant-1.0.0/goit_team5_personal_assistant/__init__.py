from .main import personal_assistant
# from goit_team5_personal_assistant.main_phone_book import CLIPhoneBook
# from main_phone_book import CLIPhoneBook
# from main_note_book import CLINoteBook
# from main_folder_sorter import run_sorter_assistant
